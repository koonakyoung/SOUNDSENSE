package org.example.registerlogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;

public class History extends AppCompatActivity {
    EditText contextEditText;
    Button save_Btn, cha_Btn, del_Btn;
    TextView diaryTextView, textView2;
    String filename, str;
    CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        contextEditText = (EditText) findViewById(R.id.contextEditText);
        diaryTextView = (TextView) findViewById(R.id.diaryTextView);
        textView2 = (TextView) findViewById(R.id.textView2);
        save_Btn = (Button) findViewById(R.id.save_Btn);
        cha_Btn = (Button) findViewById(R.id.cha_Btn);
        del_Btn = (Button) findViewById(R.id.del_Btn);
        calendarView = (CalendarView) findViewById(R.id.calendarView);


        // 오늘 날짜를 받게해주는 CalenderInstance
        Calendar c = Calendar.getInstance();
        int cYear = c.get(Calendar.YEAR);
        int cMonth = c.get(Calendar.MONTH);
        int cDay = c.get(Calendar.DAY_OF_MONTH);
        //첫화면에 오늘 날짜 체크된 거 보여줌
        checkedDay(cYear, cMonth, cDay);


        //Initialize And Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        //Set Home Selected
        bottomNavigationView.setSelectedItemId(R.id.History);
        //Preform ItemSelectedListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.Home:
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;

                    case R.id.Setting:
                        startActivity(new Intent(getApplicationContext(), Setting.class));
                        overridePendingTransition(0, 0);
                        return true;

                    case R.id.History:
                        return true;
                }
                return false;
            }
        });
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView calendarview, int cYear, int cMonth, int cDay) {
                diaryTextView.setVisibility(View.VISIBLE);//해당 날짜 뜨는 textview visible
                contextEditText.setVisibility(View.VISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
                save_Btn.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);

                diaryTextView.setText(cYear + "년" + (cMonth + 1) + "월" + cDay + "일");
                contextEditText.setText("");//EditText에 공백값 넣
                checkedDay(cYear, cMonth, cDay);

            }

        });


        save_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDiary(filename);
                Toast.makeText(getApplicationContext(), filename + "데이터를 저장했습니다.", Toast.LENGTH_SHORT).show();
                str = contextEditText.getText().toString();
                textView2.setText(str);
                contextEditText.setVisibility(View.INVISIBLE);
                cha_Btn.setVisibility(View.VISIBLE);
                del_Btn.setVisibility(View.VISIBLE);
                save_Btn.setVisibility(View.INVISIBLE);
                textView2.setVisibility(View.VISIBLE);


            }
        });

    }

    private void checkedDay(int cYear, int cMonth, int cDay) {

        diaryTextView.setText(cYear + "-" + (cMonth + 1) + "-" + cDay);//받은 날짜 보여주기
        filename = "" + cYear + "-" + (cMonth + 1) + "" + "-" + cDay + ".txt";//저장 파일 이름 만들어줌
        FileInputStream fis = null;//FileStream fis 변수 설정
        try {
            fis = openFileInput(filename);//fname file open
            byte[] fileData = new byte[fis.available()];//filedata in byte
            fis.read(fileData);
            fis.close();
            str = new String(fileData, "EUC-KR");//str에  filedata저장
            contextEditText.setVisibility(View.INVISIBLE);
            textView2.setVisibility(View.VISIBLE);
            textView2.setText(str);

            cha_Btn.setVisibility(View.VISIBLE);
            del_Btn.setVisibility(View.VISIBLE);
            save_Btn.setVisibility(View.INVISIBLE);

            if (textView2.getText() == "") {
                contextEditText.setVisibility(View.VISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
                save_Btn.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                diaryTextView.setVisibility(View.VISIBLE);
            }

            //수정버튼 누르
            cha_Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    contextEditText.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.INVISIBLE);
                    contextEditText.setText(str);//editText ->textview save output

                    cha_Btn.setVisibility(View.INVISIBLE);
                    del_Btn.setVisibility(View.INVISIBLE);
                    save_Btn.setVisibility(View.VISIBLE);
                    textView2.setText(contextEditText.getText());
                }
            });
            del_Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    contextEditText.setVisibility(View.VISIBLE);
                    cha_Btn.setVisibility(View.INVISIBLE);
                    del_Btn.setVisibility(View.INVISIBLE);
                    save_Btn.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.INVISIBLE);
                    contextEditText.setText("");
                    deleteFile(filename);
                    Toast.makeText(getApplicationContext(), filename + "데이터를 삭제했습니다", Toast.LENGTH_SHORT).show();


                }

            });

        } catch (Exception e) {//에러종류중상
            e.printStackTrace();
        }


    }

    @SuppressLint("WrongConstant")
    private void saveDiary(String readyDay) {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(readyDay, MODE_NO_LOCALIZED_COLLATORS);
            String content = contextEditText.getText().toString();
            fos.write(content.getBytes());
            fos.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("WrongConstant")
    private void removeDiary(String readyDay) {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(readyDay, MODE_NO_LOCALIZED_COLLATORS);
            String content = "";
            fos.write(content.getBytes());
            fos.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}